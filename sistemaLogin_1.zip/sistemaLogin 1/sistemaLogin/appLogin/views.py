from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login
from appLogin.forms import LoginForm, CustomUserCreationForm
from appLogin.models import CustomUser

def app_login(request):
    if request.user.is_authenticated:
        return render(request, 'home.html', {'usuario': request.user})

    return redirect('login')

def fazer_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            senha = form.cleaned_data['senha']
            user = authenticate(request, email=email, password=senha)
            if user is not None:
                login(request, user)
                return redirect('app_login')
            else:
                messages.error(request, 'Credenciais inválidas. Por favor, tente novamente.')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

def add_login(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Usuário adicionado com sucesso. Por favor, faça login.')
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'cadastro.html', {'form': form})
