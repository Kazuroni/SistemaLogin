from . import views
from django.urls import path

urlpatterns = [
    path('', views.fazerlogin, name='fazerlogin'),
    path('home/', views.appLogin, name='appLogin'),
    path('cadastro/', views.addLogin, name='add_login')
]